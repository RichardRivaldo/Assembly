#include <stdio.h>
#include <stdlib.h>

void Tokyo3Gate(char s1[]){
    if(strings_not_equal(s1, "When man stares into the abyss, the abyss stares back.")){
        // s1 = "When man stares into the abyss, the abyss stares back."
        bad_instruction();
    }
    // else print valid message
}
